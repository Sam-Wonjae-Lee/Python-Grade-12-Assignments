#Sam Wonjae Lee

#Set variable to store my name
name = "Sam"
#Friendly Message
print("Hello " + name + "!")

#Set the variable as a string with the value of 33.333333
a = "33.333333"

#The float() function can convert the string into a float
#Floats can have decimals so the variable is converted to a float
b = float(a)

#The int() function can convert the float into an integer which removes the decimals
#So the float will become an integer of a value of 33
c = int(b)

#Directly converting string with decimals to an integer will cause an error
#Output
print(c)
