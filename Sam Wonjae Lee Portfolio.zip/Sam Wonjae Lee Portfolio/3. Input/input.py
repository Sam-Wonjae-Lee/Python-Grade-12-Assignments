#Sam Wonjae Lee

#Set variable to store my name
name = "Sam"
#Friendly Message
print("Hello " + name + "!")

#Inputs for both values
num_a = int(input("Enter a value for a: "))
num_b = int(input("Enter a value for b: "))  

#Calculation of sum
num_sum = num_a + num_b

#Output
print(f'The sum of a and b is: {num_sum}')
