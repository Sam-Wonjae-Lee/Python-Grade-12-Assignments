#Sam Wonjae Lee

print("Hello World!")
