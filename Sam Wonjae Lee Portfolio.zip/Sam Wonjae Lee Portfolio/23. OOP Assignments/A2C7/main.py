#Sam Wonjae Lee
from admin import Admin

user1 = Admin("Wonjae", "Lee", "349740803", "male")
user1.privileges.show_privileges()
