#Sam Wonjae Lee
from user import Admin

user1 = Admin("Wonjae", "Lee", "349740803", "male")
user1.privileges.show_privileges()
