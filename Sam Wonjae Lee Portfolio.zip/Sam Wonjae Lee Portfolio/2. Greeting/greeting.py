#Sam Wonjae Lee

#Set variables to store my name and friend's name
myname = "Sam"
friendname = "Matthew"

#Create a variable to combine all the variables into one statement
greeting = f"Hello, my name is {myname}. Hello {friendname}! Would you like to learn some Python today?"

#Output
print(greeting)



